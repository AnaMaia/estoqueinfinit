<?php
require_once '../database/Conexao.php';
require_once '../models/TipoProduto.php';


class CrudTipoProduto
{


    private $conexao;
    public $TipoProduto;

    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }


    public function insertNovoTipo($tipoproduto){

        $sqlTipo = "INSERT INTO  tipo_produto (tipo) VALUE ('$tipoproduto->tipo')";
        $this->conexao->exec($sqlTipo);
        $idTipoProduto = $this->conexao->lastInsertId();
    }





}