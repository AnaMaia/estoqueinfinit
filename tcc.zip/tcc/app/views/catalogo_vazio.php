<?php  @ $_SESSION['tipo_user'];

if ($_SESSION['tipo_user'] == 'admin'){
    require_once __DIR__ . "/perfil_admin/indexperfil.php";

}else{
    require_once __DIR__ . "/perfil_vendedor/indexperfil.php";
}

?>
    <div id="page-wrapper">
        <!-- Page Content -->

        <div id="page-inner" class="container">
            <?php if($_SESSION['tipo_user'] == 'admin'){ ?>
                <a href="http://localhost/tcc/app/controllers/produto_controller.php?acao=cadastrar" class="ui button" >Cadastrar Novos Produtos <i class="glyphicon glyphicon-plus-sign" style=" margin-left: 5px"></i> </a>
            <?php }else{ ?>
                <h3 style="color: #0a256a">A empresa ainda não possui nenhum produto cadastrado no catálogo!</h3>
            <?php } ?>
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once __DIR__ . "/rodape.php"; ?>