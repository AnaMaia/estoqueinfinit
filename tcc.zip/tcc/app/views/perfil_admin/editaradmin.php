<?php  require_once "indexperfil.php";
@ session_start();
?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned">
                    <h1 style="margin-left: 190px;"><label><font color="#363636">Editar cadastro</font> </h1>
                </div><br>

                <!--formulario de cadastro -->
                <form class="ui form" action="?acao=atualizar" method="post">

                    <div class="field">
                        <label><font color="#363636">Nome Completo</font></label>
                        <input type="text" name="nome" value="<?= $admin->getNome(); ?>">
                    </div>
                    <div class="field">
                        <label><font color="#363636">Endereço de email</font></label>
                        <input type="email" name="email" value="<?= $admin->getEmail(); ?>">
                    </div>
                    <div class="field">
                        <label>CNPJ</label>
                        <input  type="text" class="form-control" placeholder="XX.XXX.XXX/XXXX-XX" id="cnpj" name="cnpj" value="<?= $admin->cnpj; ?>">

                        <script type="text/javascript">
                            $("#cnpj").mask("00.000.000/0000-00");
                        </script>

                    </div>
                    <div class="field">
                        <label><font color="#363636">Telefone</font></label>
                        <input type="text" class="form-control" name="telefone" placeholder="(00) 0000-0000" id="telefone" value="<?= $admin->getTelefone(); ?>">

                        <script type="text/javascript">
                            $("#telefone").mask("(00) 0000-0000");
                        </script>
                    </div>
                    <div class="field">
                        <label><font color="#363636">Razão social</font></label>
                        <input type="text" name="razao_social" value="<?= $admin->razao_social; ?>">
                    </div>
                    <div class="field">
                        <label><font color="#363636">Nome fantasia</font></label>
                        <input type="text" name="nome_fantasia" value="<?= $admin->nome_fantasia; ?>">
                    </div>
                    <div class="field">
                        <label><font color="#363636">Senha</font></label>
                        <input type="text" name="senha" value="<?= $admin->getSenha(); ?>">

                        <input type="hidden" value="<?= $admin->getIdUsuario(); ?>" name="idusu"><br><br>
                        <input style="background-color: #0a256a; margin-left: 260px; color: white;" class="ui button" type="submit" name="enviar" onclick="return confirm('Usuário editado com sucesso!');">


                    </div>
                </form>

            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>