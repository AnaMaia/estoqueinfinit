<?php  require_once "indexperfil.php"?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned">
                    <h1><label><font color="black">Cadastro de Tamanho</font></label></h1>
                </div><br>
                <form class="ui form" action="http://localhost/tcc/app/controllers/produto_controller.php?acao=salvarTamanho" method="post">

                    <div class="field">
                        <label><font color="#363636">Nome do novo tamanho</font></label>
                        <input type="text" name="tamanho" placeholder="tamanho">
                    </div>
                    <a href="#"onclick="return confirm('Novo Tamanho cadastrado com sucesso!');">

                    <button class="ui button" type="submit" style="background-color: #0a256a; color: white;" >Cadastrar</button>
                        </a>
                </form>

            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>