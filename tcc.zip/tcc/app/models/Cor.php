<?php
/**
 * Created by PhpStorm.
 * User: Ana Paula
 * Date: 28/11/2018
 * Time: 11:08
 */

class Cor
{
    public $id = null;
    public $cor;

    function __construct($cor, $id = null)
    {
        $this->cor = $cor;
        $this->id = $id;
    }
}
